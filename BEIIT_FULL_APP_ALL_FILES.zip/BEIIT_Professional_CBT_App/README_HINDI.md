# BEIIT Professional CBT Android App

Ye **Bipasha Educational Institute Of Coaching (BEIIT)** ke liye professional CBT app ka first working source-code hai.

## App me kya-kya bana hai

- BEIIT branded home screen
- Student login
- Exam sections: SSC, RBI, Railway, HP Patwari, HP Police, HP Home Guard
- Test Series buy button / purchase flow placeholder
- CBT test interface
- Timer
- Question palette
- Save & Next
- Mark for Review
- Submit Test
- Result screen
- Answer key + solution
- Result history
- Admin panel
- Admin PIN: `8988`
- Admin se new test add karne ka option
- Admin se question add karne ka option
- Contact page: 8988183059
- Address: Near Centre School, Nadaun Hamirpur Road 177033

## APK kaise banani hai

### Method 1: Android Studio se APK

1. Android Studio install karein.
2. Is ZIP ko extract karein.
3. `android-webview` folder ko Android Studio me open karein.
4. Gradle sync hone dein.
5. `Build > Build Bundle(s) / APK(s) > Build APK(s)` par click karein.
6. APK `android-webview/app/build/outputs/apk/debug/` me mil jayegi.

### Method 2: Release APK / Play Store

1. Android Studio me `Build > Generate Signed Bundle / APK` open karein.
2. APK select karein.
3. New keystore banayein.
4. Release build generate karein.

## Real live app ke liye next step

Is demo me data phone ke local storage me save hota hai. Real app ke liye ye connect karna hoga:

- Firebase Authentication
- Firebase Firestore database
- Firebase Storage for PDF notes
- Razorpay/UPI payment gateway
- Admin secure login
- Server-side test lock/unlock
- Play Store package signing

## Important files

- `web/index.html` — main app
- `web/styles.css` — design
- `web/app.js` — app logic
- `web/data.js` — exam/category/sample questions
- `android-webview/` — Android Studio project

## Branding edit

Agar aap apna original BEIIT logo lagana chahte hain, to `web/icons/` me icons replace karein aur `styles.css` me `.brandCircle` ko logo image se replace kar sakte hain.
