window.BEIIT_DATA = {
  institute: {
    name: 'Bipasha Educational Institute Of Coaching',
    short: 'BEIIT',
    phone: '8988183059',
    email: 'beiitinstitutenadaun@gmail.com',
    instagram: '@beiitinstitutenadaun',
    address: 'Near Centre School, Nadaun Hamirpur Road 177033'
  },
  categories: [
    {id:'ssc', title:'SSC Exams', icon:'📘', desc:'SSC CGL, CHSL, MTS, GD aur CPO ke CBT mock tests.', price:299},
    {id:'rbi', title:'RBI Exams', icon:'🏦', desc:'RBI Assistant / Grade B foundation mock tests.', price:499},
    {id:'railway', title:'Railway Exams', icon:'🚆', desc:'RRB NTPC, Group D, ALP level practice tests.', price:299},
    {id:'hppatwari', title:'HP Patwari', icon:'🏔️', desc:'HP Patwari 2026 syllabus based bilingual CBT tests.', price:299},
    {id:'hppolice', title:'HP Police', icon:'👮', desc:'HP Police constable written exam mock tests.', price:199},
    {id:'hphomeguard', title:'HP Home Guard', icon:'🛡️', desc:'Sankalp Vardi 2026 batch ke CBT + OMR practice tests.', price:199}
  ],
  tests: [
    {id:'hp-patwari-demo', category:'hppatwari', title:'HP Patwari Mock Test 01', duration:90, marks:10, lang:'Bilingual', free:true},
    {id:'ssc-demo', category:'ssc', title:'SSC CGL Mini Mock 01', duration:60, marks:10, lang:'English + Hindi', free:true},
    {id:'homeguard-demo', category:'hphomeguard', title:'HP Home Guard Written Mock 01', duration:45, marks:10, lang:'Hindi', free:true}
  ],
  questions: {
    'hp-patwari-demo': [
      {q:'Himachal Pradesh का गठन Chief Commissioner Province के रूप में कब हुआ?', qh:'Himachal Pradesh का गठन Chief Commissioner Province के रूप में कब हुआ?', options:['15 April 1948','25 January 1971','1 November 1966','26 January 1950'], answer:0, solution:'हिमाचल प्रदेश 15 अप्रैल 1948 को Chief Commissioner Province बना था।'},
      {q:'Which river is associated with Chamba valley?', qh:'चंबा घाटी मुख्य रूप से किस नदी से संबंधित है?', options:['Ravi','Beas','Chenab','Satluj'], answer:0, solution:'Chamba valley is mainly associated with the Ravi river.'},
      {q:'If 25% of a number is 80, then the number is:', qh:'किसी संख्या का 25% यदि 80 है, तो संख्या कितनी है?', options:['240','280','300','320'], answer:3, solution:'25% = 1/4. Number = 80 × 4 = 320.'},
      {q:'Choose the synonym of “Abundant”.', qh:'“Abundant” का समानार्थी शब्द चुनिए।', options:['Scarce','Plenty','Tiny','Weak'], answer:1, solution:'Abundant means plenty or more than enough.'},
      {q:'भारत के संविधान में मूल अधिकार किस भाग में दिए गए हैं?', qh:'भारत के संविधान में मूल अधिकार किस भाग में दिए गए हैं?', options:['भाग I','भाग II','भाग III','भाग IV'], answer:2, solution:'मूल अधिकार संविधान के भाग III में दिए गए हैं।'},
      {q:'Computer में CPU का full form क्या है?', qh:'Computer में CPU का full form क्या है?', options:['Central Process Unit','Central Processing Unit','Control Processing Unit','Central Power Unit'], answer:1, solution:'CPU = Central Processing Unit.'},
      {q:'Find the missing number: 3, 6, 12, 24, ?', qh:'रिक्त स्थान भरें: 3, 6, 12, 24, ?', options:['30','36','42','48'], answer:3, solution:'Every term is multiplied by 2. 24 × 2 = 48.'},
      {q:'HP की राजधानी क्या है?', qh:'HP की राजधानी क्या है?', options:['Dharamshala','Shimla','Mandi','Hamirpur'], answer:1, solution:'Shimla is the capital of Himachal Pradesh.'},
      {q:'The antonym of “Ancient” is:', qh:'“Ancient” का विलोम शब्द है:', options:['Old','Modern','Past','Historic'], answer:1, solution:'Ancient ka opposite Modern hota hai.'},
      {q:'भारत में पंचायती राज को संवैधानिक दर्जा किस संशोधन से मिला?', qh:'भारत में पंचायती राज को संवैधानिक दर्जा किस संशोधन से मिला?', options:['42वां','44वां','73वां','86वां'], answer:2, solution:'73वें संविधान संशोधन 1992 से पंचायती राज को संवैधानिक दर्जा मिला।'}
    ],
    'ssc-demo': [],
    'homeguard-demo': []
  }
};
window.BEIIT_DATA.questions['ssc-demo'] = window.BEIIT_DATA.questions['hp-patwari-demo'];
window.BEIIT_DATA.questions['homeguard-demo'] = window.BEIIT_DATA.questions['hp-patwari-demo'];
