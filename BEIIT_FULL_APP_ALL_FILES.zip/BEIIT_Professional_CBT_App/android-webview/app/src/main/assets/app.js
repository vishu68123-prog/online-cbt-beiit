const $ = sel => document.querySelector(sel);
const app = $('#app');
const DATA = window.BEIIT_DATA;
const store = {
  get(k, fallback){ try { return JSON.parse(localStorage.getItem(k)) ?? fallback; } catch { return fallback; }},
  set(k,v){ localStorage.setItem(k, JSON.stringify(v)); }
};
let state = {
  user: store.get('beiit_user', null),
  page: 'home',
  selectedCategory: null,
  activeTest: null,
  qIndex: 0,
  answers: {},
  review: {},
  remaining: 0,
  timer: null,
  result: null,
  lang: store.get('beiit_lang', 'both')
};

function logo(){ return document.getElementById('logoTpl').innerHTML; }
function escapeHtml(s=''){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function saveUser(user){ state.user=user; store.set('beiit_user', user); render(); }
function purchased(){return store.get('beiit_purchased', []);}
function addPurchased(cat){ const p=[...new Set([...purchased(),cat])]; store.set('beiit_purchased',p); render(); }
function tests(){ const custom=store.get('beiit_custom_tests', []); return [...DATA.tests, ...custom]; }
function questions(testId){ return store.get(`beiit_questions_${testId}`, null) || DATA.questions[testId] || []; }
function isPaid(cat){ return purchased().includes(cat); }

function render(){
  if(!state.user) return renderLogin();
  if(state.page==='exam') return renderExam();
  if(state.page==='result') return renderResult();
  app.innerHTML = `<div class="appShell"><div class="watermark">BEIIT</div><div class="contentLayer">${topbar()}<main class="container">${pageHtml()}</main>${nav()}</div></div>`;
}
function topbar(){return `<header class="topbar"><div class="brand">${logo()}<div><h1>${DATA.institute.name}</h1><p>Professional CBT Test Series App</p></div></div><div class="userChip"><div class="avatar">${escapeHtml((state.user.name||'S')[0]).toUpperCase()}</div><span>${escapeHtml(state.user.name||'Student')}</span></div></header>`;}
function nav(){ const items=[['home','🏠','Home'],['tests','📝','Tests'],['resultHistory','📊','Results'],['admin','⚙️','Admin'],['contact','☎️','Contact']]; return `<nav class="navbar">${items.map(([p,i,t])=>`<button class="navBtn ${state.page===p?'active':''}" onclick="go('${p}')"><span>${i}</span><span>${t}</span></button>`).join('')}</nav>`; }
function go(page){ state.page=page; state.selectedCategory=null; render(); }

function renderLogin(){
  app.innerHTML = `<div class="loginWrap"><div class="loginCard"><div class="loginHead">${logo()}<h1>BEIIT CBT App</h1><p>Login karke online test series start karein</p></div><div class="form">
    <div class="field"><label>Student Name</label><input id="name" placeholder="Apna naam likhein" value="Vishal Kumar"></div>
    <div class="field"><label>Mobile Number</label><input id="mobile" placeholder="10 digit mobile" value="8988183059"></div>
    <div class="field"><label>Target Exam</label><select id="target">${DATA.categories.map(c=>`<option value="${c.title}">${c.title}</option>`).join('')}</select></div>
    <button class="btn" onclick="login()">Login / Start App</button>
    <div class="notice">Admin demo ke liye: Admin tab me PIN <b>8988</b> use karein. Real app me Firebase/Auth + Payment Gateway connect karna hoga.</div>
  </div></div></div>`;
}
function login(){ const name=$('#name').value.trim()||'Student'; const mobile=$('#mobile').value.trim(); const target=$('#target').value; saveUser({name,mobile,target,joined:new Date().toISOString()}); }
function pageHtml(){
  if(state.page==='home') return homeHtml();
  if(state.page==='tests') return testsHtml();
  if(state.page==='resultHistory') return historyHtml();
  if(state.page==='admin') return adminHtml();
  if(state.page==='contact') return contactHtml();
  return homeHtml();
}
function homeHtml(){return `<section class="hero">${logo()}<h2>Online CBT Test Portal</h2><p>BEIIT app me SSC, RBI, Railway, HP Patwari, HP Police aur HP Home Guard ke professional CBT mock tests, result, answer key aur admin panel available hai.</p><div class="actions"><button class="btn orange" onclick="go('tests')">Test Series Dekhein</button><button class="btn secondary" onclick="go('admin')">Admin Panel</button></div><div class="heroStats"><div class="stat"><b>${DATA.categories.length}+</b><span>Exam Sections</span></div><div class="stat"><b>90 Min</b><span>CBT Timer Support</span></div><div class="stat"><b>24×7</b><span>Practice Access</span></div></div></section><div class="sectionTitle"><h3>Exam Sections</h3><span class="muted">Buy + Start Test</span></div><div class="grid">${DATA.categories.map(examCard).join('')}</div>`;}
function examCard(c){return `<div class="card span4 examCard"><div class="examIcon">${c.icon}</div><span class="badge">${isPaid(c.id)?'Purchased':'Test Series'}</span><h4>${c.title}</h4><p>${c.desc}</p><div class="price">₹${c.price}</div><div class="actions"><button class="btn small" onclick="selectCat('${c.id}')">Open</button><button class="btn small secondary" onclick="buy('${c.id}')">${isPaid(c.id)?'Paid':'Buy Now'}</button></div></div>`;}
function selectCat(id){ state.page='tests'; state.selectedCategory=id; render(); }
function buy(id){
  const c=DATA.categories.find(x=>x.id===id);
  addPurchased(id);
  alert(`${c.title} test series demo purchase successful. Real app me Razorpay/UPI gateway connect hoga.`);
}
function testsHtml(){ const cats=DATA.categories; const cat=state.selectedCategory||cats[0].id; const c=cats.find(x=>x.id===cat); const list=tests().filter(t=>t.category===cat); return `<div class="sectionTitle"><h3>Test Series</h3><select onchange="selectCat(this.value)">${cats.map(x=>`<option value="${x.id}" ${x.id===cat?'selected':''}>${x.title}</option>`).join('')}</select></div><div class="card span12"><h3>${c.icon} ${c.title}</h3><p class="muted">${c.desc}</p><div class="notice">Paid tests start karne ke liye Buy Now ka flow connect hota hai. Demo tests free start honge.</div></div><div class="grid">${list.map(t=>testCard(t,c)).join('') || '<div class="card span12">Is section me abhi test add nahi hua. Admin panel se test add karein.</div>'}</div>`;}
function testCard(t,c){ const unlocked=t.free || isPaid(c.id); return `<div class="card span6 examCard"><span class="badge">${t.free?'Free Demo':unlocked?'Unlocked':'Locked'}</span><h4>${t.title}</h4><p>Duration: ${t.duration} minutes • Marks: ${t.marks} • Language: ${t.lang}</p><div class="actions"><button class="btn ${unlocked?'green':''}" ${unlocked?'':'disabled'} onclick="startTest('${t.id}')">Start CBT</button>${unlocked?'':`<button class="btn orange" onclick="buy('${c.id}')">Buy ₹${c.price}</button>`}</div></div>`; }
function startTest(id){ state.activeTest=tests().find(t=>t.id===id); state.qIndex=0; state.answers={}; state.review={}; state.remaining=(state.activeTest.duration||30)*60; state.page='exam'; render(); startTimer(); }
function startTimer(){ clearInterval(state.timer); state.timer=setInterval(()=>{ state.remaining--; const el=$('#timer'); if(el) el.textContent=formatTime(state.remaining); if(state.remaining<=0){submitTest();}},1000); }
function formatTime(sec){ sec=Math.max(0,sec); const m=Math.floor(sec/60), s=sec%60; return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`; }
function renderExam(){ const qs=questions(state.activeTest.id); const q=qs[state.qIndex]; if(!q){return submitTest();} app.innerHTML=`<div class="testShell"><div class="examTop"><b>${state.activeTest.title}</b><span class="timer" id="timer">${formatTime(state.remaining)}</span></div><div class="examBody"><main class="questionPanel"><div class="questionCard"><div class="questionMeta"><span>Question ${state.qIndex+1} of ${qs.length}</span><span>${state.activeTest.lang}</span></div><p class="qText">${displayQuestion(q)}</p>${q.options.map((op,i)=>`<label class="option ${state.answers[state.qIndex]===i?'selected':''}"><input type="radio" name="op" ${state.answers[state.qIndex]===i?'checked':''} onchange="choose(${i})"><span><b>${String.fromCharCode(65+i)}.</b> ${escapeHtml(op)}</span></label>`).join('')}</div></main><aside class="candidatePanel"><div class="candidateBox"><div class="candidatePhoto">👤</div><div><b>${escapeHtml(state.user.name)}</b><br><span class="muted">${escapeHtml(state.user.target)}</span></div></div><div class="paletteBox"><b>Question Palette</b><div class="legend"><span class="legendItem"><i class="dot green"></i>Answered</span><span class="legendItem"><i class="dot red"></i>Not Answered</span><span class="legendItem"><i class="dot purple"></i>Review</span><span class="legendItem"><i class="dot"></i>Not Visited</span></div><div class="palette">${qs.map((_,i)=>`<button class="qNo ${qClass(i)}" onclick="jump(${i})">${i+1}</button>`).join('')}</div></div></aside></div><div class="examActions"><button class="btn secondary" onclick="prevQ()">Previous</button><button class="btn" onclick="nextQ()">Save & Next</button><button class="btn ghost" onclick="markReview()">Mark for Review</button><button class="btn red" onclick="submitTest(true)">Submit Test</button></div></div>`; }
function displayQuestion(q){ if(state.lang==='hindi') return escapeHtml(q.qh||q.q); if(state.lang==='english') return escapeHtml(q.q); return `${escapeHtml(q.q)}<br><span class="muted">${escapeHtml(q.qh||'')}</span>`; }
function qClass(i){ if(i===state.qIndex) return 'current'; if(state.review[i]) return 'review'; if(state.answers[i]!==undefined) return 'answered'; if(i<state.qIndex) return 'notanswered'; return ''; }
function choose(i){ state.answers[state.qIndex]=i; renderExam(); }
function jump(i){ state.qIndex=i; renderExam(); }
function prevQ(){ if(state.qIndex>0){state.qIndex--; renderExam();} }
function nextQ(){ const qs=questions(state.activeTest.id); if(state.qIndex<qs.length-1){state.qIndex++; renderExam();} }
function markReview(){ state.review[state.qIndex]=!state.review[state.qIndex]; nextQ(); }
function submitTest(confirmAsk=false){ if(confirmAsk && !confirm('Submit test now?')) return; clearInterval(state.timer); const qs=questions(state.activeTest.id); let correct=0, attempted=0; qs.forEach((q,i)=>{ if(state.answers[i]!==undefined) attempted++; if(state.answers[i]===q.answer) correct++; }); const res={id:Date.now(), test:state.activeTest.title, date:new Date().toLocaleString(), total:qs.length, attempted, correct, score:correct, answers:state.answers, testId:state.activeTest.id}; const hist=store.get('beiit_results', []); hist.unshift(res); store.set('beiit_results',hist); state.result=res; state.page='result'; render(); }
function renderResult(){ const r=state.result; const qs=questions(r.testId); const pct=Math.round((r.correct/r.total)*100); app.innerHTML=`<div class="appShell"><div class="watermark">BEIIT</div><div class="contentLayer">${topbar()}<main class="container"><div class="card resultBox"><h2>Result Declared</h2><p class="muted">${escapeHtml(r.test)} • ${r.date}</p><div class="scoreCircle" style="--score:${pct}%"><span>${r.correct}/${r.total}</span></div><div class="grid"><div class="card span4"><b>Attempted</b><br>${r.attempted}</div><div class="card span4"><b>Correct</b><br>${r.correct}</div><div class="card span4"><b>Percentage</b><br>${pct}%</div></div><div class="actions" style="justify-content:center;margin-top:15px"><button class="btn" onclick="go('tests')">Back to Tests</button><button class="btn secondary" onclick="window.print()">Print Result</button></div></div><div class="sectionTitle"><h3>Answer Key + Solution</h3></div>${qs.map((q,i)=>answerHtml(q,i,r.answers[i])).join('')}</main>${nav()}</div></div>`; }
function answerHtml(q,i,ans){ const ok=ans===q.answer; return `<div class="answerRow ${ok?'correct':'wrong'}"><h4>Q${i+1}. ${displayQuestion(q)}</h4><p><b>Your Answer:</b> ${ans===undefined?'Not Attempted':String.fromCharCode(65+ans)+'. '+escapeHtml(q.options[ans])}</p><p><b>Correct Answer:</b> ${String.fromCharCode(65+q.answer)}. ${escapeHtml(q.options[q.answer])}</p><p class="muted"><b>Solution:</b> ${escapeHtml(q.solution)}</p></div>`; }
function historyHtml(){ const hist=store.get('beiit_results', []); return `<div class="sectionTitle"><h3>My Results</h3></div><div class="card"><table class="table"><thead><tr><th>Test</th><th>Date</th><th>Score</th><th>Attempted</th></tr></thead><tbody>${hist.map(r=>`<tr><td>${escapeHtml(r.test)}</td><td>${escapeHtml(r.date)}</td><td><span class="pill">${r.correct}/${r.total}</span></td><td>${r.attempted}</td></tr>`).join('') || '<tr><td colspan="4">Abhi koi result available nahi hai.</td></tr>'}</tbody></table></div>`; }
function adminHtml(){ const unlocked=store.get('beiit_admin', false); if(!unlocked) return `<div class="card"><h2>Admin Login</h2><p class="muted">Questions, test series aur notices manage karne ke liye PIN enter karein.</p><div class="form"><div class="field"><label>Admin PIN</label><input id="pin" type="password" placeholder="PIN"></div><button class="btn" onclick="adminLogin()">Open Admin Panel</button></div></div>`; return `<div class="sectionTitle"><h3>Admin Panel</h3><button class="btn small secondary" onclick="adminLogout()">Logout Admin</button></div><div class="grid"><div class="card span6"><h3>Add Test Series</h3><div class="form"><div class="field"><label>Exam Category</label><select id="tcat">${DATA.categories.map(c=>`<option value="${c.id}">${c.title}</option>`).join('')}</select></div><div class="field"><label>Test Title</label><input id="ttitle" placeholder="Example: HP Patwari Mock Test 02"></div><div class="field"><label>Duration Minutes</label><input id="tdur" type="number" value="90"></div><button class="btn" onclick="addTest()">Add Test</button></div></div><div class="card span6"><h3>Add Question</h3><div class="form"><div class="field"><label>Test</label><select id="qtest">${tests().map(t=>`<option value="${t.id}">${t.title}</option>`).join('')}</select></div><div class="field"><label>Question</label><textarea id="qq"></textarea></div><div class="field"><label>Options, one per line</label><textarea id="qops">A\nB\nC\nD</textarea></div><div class="field"><label>Correct Option Number 1-4</label><input id="qans" type="number" min="1" max="4" value="1"></div><div class="field"><label>Solution</label><textarea id="qsol"></textarea></div><button class="btn" onclick="addQuestion()">Add Question</button></div></div><div class="card span12"><h3>Current Tests</h3><table class="table"><thead><tr><th>Title</th><th>Category</th><th>Duration</th><th>Questions</th></tr></thead><tbody>${tests().map(t=>`<tr><td>${escapeHtml(t.title)}</td><td>${escapeHtml(t.category)}</td><td>${t.duration} min</td><td>${questions(t.id).length}</td></tr>`).join('')}</tbody></table></div></div>`; }
function adminLogin(){ if($('#pin').value==='8988'){store.set('beiit_admin',true);render();} else alert('Wrong PIN'); }
function adminLogout(){ store.set('beiit_admin',false); render(); }
function addTest(){ const title=$('#ttitle').value.trim(); if(!title) return alert('Test title required'); const id='custom-'+Date.now(); const custom=store.get('beiit_custom_tests', []); custom.push({id, category:$('#tcat').value, title, duration:+$('#tdur').value||90, marks:0, lang:'Hindi + English', free:false}); store.set('beiit_custom_tests', custom); store.set(`beiit_questions_${id}`, []); render(); }
function addQuestion(){ const id=$('#qtest').value; const q=$('#qq').value.trim(); const ops=$('#qops').value.split('\n').map(x=>x.trim()).filter(Boolean); if(!q||ops.length<2) return alert('Question/options required'); const list=questions(id); list.push({q,qh:q,options:ops,answer:(+$('#qans').value||1)-1,solution:$('#qsol').value.trim()}); store.set(`beiit_questions_${id}`, list); alert('Question added'); render(); }
function contactHtml(){return `<div class="card"><h2>Contact BEIIT</h2><div class="contactItem">☎️ <div><b>Call / WhatsApp</b><br><a href="tel:${DATA.institute.phone}">${DATA.institute.phone}</a></div></div><div class="contactItem">📍 <div><b>Address</b><br>${DATA.institute.address}</div></div><div class="contactItem">📧 <div><b>Email</b><br>${DATA.institute.email}</div></div><div class="contactItem">📸 <div><b>Instagram</b><br>${DATA.institute.instagram}</div></div><div class="notice" style="margin-top:14px">Professional live app me Firebase database, Razorpay payment gateway, secure login aur Play Store release setup connect kiya jayega.</div></div>`;}
render();
