#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
gradle assembleDebug
echo "APK ready: app/build/outputs/apk/debug/app-debug.apk"
