# BEIIT CBT App APK kaise banaye

Is ZIP me Android WebView app source ready hai. Is environment me Android SDK/Gradle available nahi tha, isliye direct APK yahin compile nahi ho payi. APK banane ke liye ye 2 asaan tareeke hain:

## Tareeka 1: Android Studio se APK

1. ZIP extract karo.
2. Android Studio install/open karo.
3. **Open** par click karo.
4. Ye folder select karo:
   `BEIIT_Professional_CBT_App/android-webview`
5. Project load hone do.
6. Menu me jao: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
7. APK yahan milegi:
   `android-webview/app/build/outputs/apk/debug/app-debug.apk`
8. Phone me APK bhejo, **Install unknown apps** allow karo, install karo.

## Tareeka 2: GitHub Actions se APK

1. GitHub par new repository banao.
2. Is ZIP ka poora content repository me upload karo.
3. Repository ke **Actions** tab me jao.
4. Workflow **Build BEIIT Android APK** select karo.
5. **Run workflow** par click karo.
6. Build complete hone ke baad **Artifacts** me `BEIIT-CBT-debug-apk` download karo.
7. Us ZIP ke andar `app-debug.apk` milegi.

## Admin PIN

Admin panel PIN: `8988`

## Important

Ye debug APK hai. Students ko distribute karne ke liye final signed release APK/App Bundle banani hogi. Real payment, Firebase login/database, and Play Store release ke liye release signing key aur payment gateway integration required hoga.
